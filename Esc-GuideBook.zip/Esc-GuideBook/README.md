Discord : https://discord.gg/z52kuHNtUg

Tebex : https://esc.tebex.io